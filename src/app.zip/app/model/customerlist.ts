export class CustomerList{
    public Name: string;
    public WaterMeterNo: number;
    public CustomerCode: number;
    public Address: string;
    public PhoneNo: number;
    public PresentMR: number;
    public PreviousMR: number;
    
}